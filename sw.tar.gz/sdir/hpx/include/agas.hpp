//  Copyright (c) 2107 Hartmut Kaiser
//
//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#if !defined(HPX_AGAS_DEC_11_2017_0530PM)
#define HPX_AGAS_DEC_11_2017_0530PM

#include <hpx/runtime/agas/interface.hpp>

#endif

